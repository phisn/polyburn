import * as tf from "@tensorflow/tfjs"
import { Kwargs } from "@tensorflow/tfjs-layers/dist/types"
import { GaussianLikelihood } from "./gaussian-likelihood"
import { MlpSpecification, mlp } from "./mlp"

const LOG_STD_MIN = -20
const LOG_STD_MAX = 2

export class Actor extends tf.layers.Layer {
    private gaussianLikelihood: tf.layers.Layer

    private net: tf.Sequential
    private meanLayer: tf.layers.Layer
    private stdevLayer: tf.layers.Layer

    constructor(observationSize: number, actionSize: number, mlpSpec: MlpSpecification) {
        super()

        this.net = mlp({
            ...mlpSpec,
            sizes: [observationSize, ...mlpSpec.sizes],
        })

        this.meanLayer = tf.layers.dense({
            units: actionSize,
        })

        this.stdevLayer = tf.layers.dense({
            units: actionSize,
        })

        this.gaussianLikelihood = new GaussianLikelihood()
    }

    call(x: tf.Tensor<tf.Rank>, kwargs: Kwargs): tf.Tensor<tf.Rank>[] {
        x = this.net.apply(x) as tf.Tensor<tf.Rank>

        const mu = this.meanLayer.apply(x) as tf.Tensor<tf.Rank>
        const logSigma = this.stdevLayer.apply(x) as tf.Tensor<tf.Rank>
        const logSigmaClipped = tf.clipByValue(logSigma, LOG_STD_MIN, LOG_STD_MAX)
        const sigma = tf.exp(logSigmaClipped)

        let action: tf.Tensor

        if (kwargs.deterministic) {
            action = mu
        } else {
            action = tf.add(mu, tf.mul(sigma, tf.randomNormal(mu.shape, 0, 1, "float32")))
        }

        let actionLogProb = this.logProb(action, mu, sigma).sum(-1)

        actionLogProb = actionLogProb.sub(
            tf.sum(
                tf.mul(2, tf.sub(Math.log(2), tf.add(action, tf.softplus(tf.mul(-2, action))))),
                1,
            ),
        )

        action = tf.tanh(action)

        return [action, actionLogProb]
    }

    static get className() {
        return "Actor"
    }

    private logProb(x: tf.Tensor<tf.Rank>, mu: tf.Tensor<tf.Rank>, sigma: tf.Tensor<tf.Rank>) {
        const twoPi = tf.scalar(2 * Math.PI)
        const logSigma = tf.log(sigma)
        const logTwoPiSigma2 = tf.add(tf.log(twoPi), tf.mul(2, tf.square(logSigma)))
        const diff = tf.sub(x, mu)
        const sqrDiff = tf.square(diff)
        const sigma2 = tf.square(sigma)
        const expComponent = tf.div(sqrDiff, tf.mul(2, sigma2))

        return tf.neg(tf.add(tf.div(logTwoPiSigma2, 2), expComponent))
    }
}

tf.serialization.registerClass(Actor)
